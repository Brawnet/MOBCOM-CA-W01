//
//  Set.swift
//  W06
//
//  Created by student on 16/10/25.
//

import Foundation
import SwiftUI

struct SetView: View {
    @State private var programmingLanguage: Set<String> = [
        "Swift",
        "Phyton",
        "JavaScript",
        "Java"
    ]
    
    @State private var newLanguage: String = ""
    @State private var deleteLanguage: String = ""
    @State private var deleteMessage: String? = nil
    
    var body: some View {
        VStack(spacing: 16) {
            Text("ini adalah set")
                .font(.largeTitle)
            
            // Daftar bahasa dalam bentuk chips
            WrapView(items: Array(programmingLanguage.sorted()), id: \.self) { lang in
                Text(lang)
                    .padding(.vertical, 6)
                    .padding(.horizontal, 10)
                    .background(Color.green.opacity(0.2))
                    .clipShape(Capsule())
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            // Form tambah
            VStack(alignment: .leading, spacing: 8) {
                Text("Tambah Bahasa")
                    .font(.headline)
                HStack {
                    TextField("Nama bahasa baru", text: $newLanguage)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.words)
                    Button("Add") {
                        let trimmed = newLanguage.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty else { return }
                        programmingLanguage.insert(trimmed)
                        newLanguage = ""
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(newLanguage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            
            // Form hapus
            VStack(alignment: .leading, spacing: 8) {
                Text("Hapus Bahasa")
                    .font(.headline)
                HStack {
                    TextField("Nama bahasa yang akan dihapus", text: $deleteLanguage)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.words)
                    Button("Delete") {
                        let target = deleteLanguage.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !target.isEmpty else { return }
                        if programmingLanguage.contains(target) {
                            programmingLanguage.remove(target)
                            deleteMessage = "Berhasil menghapus \"\(target)\"."
                        } else {
                            deleteMessage = "\"\(target)\" tidak ditemukan."
                        }
                        deleteLanguage = ""
                    }
                    .buttonStyle(.bordered)
                    .disabled(deleteLanguage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                if let msg = deleteMessage {
                    Text(msg)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            
            Spacer(minLength: 0)
        }
        .padding()
    }
}

// Helper sederhana untuk membungkus item seperti flow layout
private struct WrapView<Data: RandomAccessCollection, ID: Hashable, Content: View>: View where Data.Element: Hashable {
    let items: Data
    let id: KeyPath<Data.Element, ID>
    let content: (Data.Element) -> Content
    
    init(items: Data, id: KeyPath<Data.Element, ID>, @ViewBuilder content: @escaping (Data.Element) -> Content) {
        self.items = items
        self.id = id
        self.content = content
    }
    
    var body: some View {
        GeometryReader { geo in
            self.generateContent(in: geo.size.width)
        }
        .frame(minHeight: 0)
    }
    
    private func generateContent(in totalWidth: CGFloat) -> some View {
        var width = CGFloat.zero
        var height = CGFloat.zero
        
        return ZStack(alignment: .topLeading) {
            ForEach(Array(items), id: id) { item in
                content(item)
                    .padding(4)
                    .alignmentGuide(.leading) { d in
                        if abs(width - d.width) > totalWidth {
                            width = 0
                            height -= d.height
                        }
                        let result = width
                        width -= d.width
                        return result
                    }
                    .alignmentGuide(.top) { _ in
                        let result = height
                        return result
                    }
            }
        }
    }
}

#Preview {
    SetView()
}
