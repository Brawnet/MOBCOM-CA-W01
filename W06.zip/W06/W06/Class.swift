//
//  Class.swift
//  W06
//
//  Created by student on 16/10/25.
//

import Foundation
import SwiftUI

struct Class1: View {
    struct Counter {
        var count: Int = 1
        mutating func increment() { count += 1 }
        mutating func decrement() { count -= 1 }
    }
    
    @State private var counterA = Counter()
    @State private var counterB = Counter()
    
    var body: some View {
        VStack {
            Text("Counter A: \(counterA.count)")
            HStack
            {
                Button("Increment") {
                    counterA.increment()
                }
                Button("Decrement") {
                    counterA.decrement()
                }
            }

            Text("Counter B: \(counterB.count)")
            
            HStack
            {
                Button("Increment") {
                    counterB.increment()
                }
                Button("Decrement") {
                    counterB.decrement()
                }
            }
        }
    }
}

#Preview {
    Class1()
}
