//
//  Enum.swift
//  W06
//
//  Created by student on 16/10/25.
//

import Foundation
import SwiftUI

struct Enum: View {
    enum Grade: String, CaseIterable {
        case A, B, C, D, E
        
        var color: Color {
            switch self {
            case .A: return .blue
            case .B: return .green
            case .C: return .yellow
            case .D: return .orange
            case .E: return .red
            }
        }
    }
    
    
    @State private var grade: Grade = .A
    var body: some View {
        VStack {
            Picker("Select Grade", selection: $grade)
            {
                ForEach(Grade.allCases, id: \.self)
                {
                    g in Text(g.rawValue)
                }
            }
            .pickerStyle(.segmented)
            
            Text ("Your Grade: \(grade.rawValue)")
                .font(.largeTitle)
                .foregroundStyle(grade.color)
        }
    }
}

#Preview {
    Enum()
}
