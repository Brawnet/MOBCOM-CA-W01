//
//  ContentView.swift
//  W06
//
//  Created by student on 16/10/25.
//

import SwiftUI

struct Dictionary: View {
    @State private var scores: [String: Int] =
    [
        "Alice": 90,
        "Martini": 80,
        "Sutris": 20,
    ]
    
    @State private var inputName: String = ""
    
    var body: some View {
        VStack {
            Text("Dictionary Explanation")
                .font(.largeTitle)
            
            VStack {
                ForEach(scores.sorted(by: { $0.key < $1.key }), id: \.key) { name, score in
                    HStack {
                        Text(name)
                        Spacer()
                        Text("\(score)")
                            .bold(true)
                    }
                }
            }
            
            HStack {
                Button("Increase Sutris Score!") {
                    scores["Sutris", default: 0] += 5
                }
            }
            .padding(.top, 8)
            
            // TextField untuk input
            VStack(alignment: .leading, spacing: 8) {
                TextField("Name", text: $inputName)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.words)
                
                Button("Add") {
                    scores[inputName, default: 0] += 5
                }
                .buttonStyle(.borderedProminent)
                Button("Remove All")
                {
                    scores.removeAll()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.top, 12)
        }
        .padding()
    }
}

#Preview {
    Dictionary()
}
