//
//  Tuple.swift
//  W06
//
//  Created by student on 16/10/25.
//

import Foundation
import SwiftUI

struct Tuple: View {
    @State private var point: (x: Int, y: Int) = (x: 0, y: 0)
    
    var body: some View {
        Text("ini adalah tuple")
            .font(.largeTitle)
        
        Text("Nilai sekarang XY : \(point.x), \(point.y)")
        
        HStack
        {
            Button("Kanan 10 Langkah")
            {
                point.x += 10
            }
            .buttonStyle(.borderedProminent)
            Button("Bawah 10 Langkah")
            {
                point.y -= 10
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

#Preview {
    Tuple()
}

