//
//  CoreDataStudentView.swift
//  W06
//
//  Created by student on 16/10/25.
//

import Foundation
import SwiftUI
import CoreData

struct CoreDataStudentView: View {
    let vm: CoreDataStudentViewModel
    
    @State private var newName: String = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    TextField("Enter Student Name", text: $newName)
                        .textFieldStyle(.roundedBorder)
                    Button("Add") {
                        vm.add(name: newName)
                        newName = ""
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(newName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding(.horizontal)
                
                List {
                    ForEach(vm.students, id: \.objectID) { s in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(s.name ?? "(no name)")
                                    .font(.headline)
                                if s.isFavorite {
                                    Text("❤️ Favorite")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Button {
                                vm.toggleFavorite(s)
                            } label: {
                                Image(systemName: s.isFavorite ? "heart.fill" : "heart")
                                    .foregroundColor(.red)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .onDelete(perform: vm.delete)
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("Student Core Data")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    EditButton()
                }
            }
        }
    }
}

#Preview {
    let pc = PersistanceController.shared
    let context = pc.container.viewContext
    let vm = CoreDataStudentViewModel(context: context)
    return CoreDataStudentView(vm: vm)
}
