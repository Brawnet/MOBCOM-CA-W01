//
//  W06App.swift
//  W06
//
//  Created by student on 16/10/25.
//

import SwiftUI
import CoreData

@main
struct W06App: App {
    var body: some Scene {
        WindowGroup {
            let pc = PersistanceController.shared
            let context = pc.container.viewContext
            let vm = CoreDataStudentViewModel(context: context)
            CoreDataStudentView(vm: vm)
        }
    }
}
