//
//  CoreDataStudentViewModel.swift
//  W06
//
//  Created by student on 16/10/25.
//

import Foundation
import CoreData
import Observation

@Observable
@MainActor
final class CoreDataStudentViewModel {
    private let context: NSManagedObjectContext
    
    var students: [Student_Entitity] = []
    
    init(context: NSManagedObjectContext){
        self.context = context
        fetch()
    }
    
    func fetch()
    {
        let request: NSFetchRequest<Student_Entitity> =
        Student_Entitity.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        do {
            students = try context.fetch(request)
        }
        catch{
            print("fetch error : ", error)
        }
    }
    func toggleFavorite(_ s: Student_Entitity){
        s.isFavorite.toggle()
        saveAndRefresh()
    }
    
    func delete (at offsets: IndexSet){
        for i in offsets{
            context.delete(students[i])
        }
        saveAndRefresh()
    }
    
    func add(name: String){
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        let s = Student_Entitity(context: context)
        s.name = trimmed
        s.isFavorite = false
        saveAndRefresh()
    }
    
    public func saveAndRefresh() {
        do {
            try context.save()
        }
        catch {
            print("Save Error: ", error)
            context.rollback()
        }
        fetch()
    }
}
