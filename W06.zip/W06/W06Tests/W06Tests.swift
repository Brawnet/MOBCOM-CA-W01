//
//  W06Tests.swift
//  W06Tests
//
//  Created by student on 16/10/25.
//

import Testing
@testable import W06

struct W06Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
