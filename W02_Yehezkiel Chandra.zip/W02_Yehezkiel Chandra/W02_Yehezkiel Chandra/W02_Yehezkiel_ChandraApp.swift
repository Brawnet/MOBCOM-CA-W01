//
//  W02_Yehezkiel_ChandraApp.swift
//  W02_Yehezkiel Chandra
//
//  Created by Muh. Nur Alif Akbar on 24/09/25.
//

import SwiftUI

@main
struct W02_Yehezkiel_ChandraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
