import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    var title: String
    var isDone: Bool = false
}

struct ContentView: View {
    @State private var tasks: [Task] = []
    @State private var newTask: String = ""

    var body: some View {
        NavigationView {
            VStack {
                Text("To-Do List")
                    .font(Font.largeTitle.bold())
                    .padding(.horizontal, -180)
                    .padding(.vertical, 30)
                    .padding(.bottom, -50)
                HStack {
                    TextField("Apa yang mau kamu lakukan?", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    
                    Button(action: {
                        if !newTask.isEmpty {
                            tasks.append(Task(title: newTask))
                            newTask = ""
                        }
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title)
                            .foregroundColor(.blue)
                    }
                    .padding(.trailing)
                }
                .padding(.vertical)

                List {
                    ForEach(tasks) { task in
                        HStack {
                            Button(action: {
                                if let index = tasks.firstIndex(where: { $0.id == task.id }) {
                                    tasks[index].isDone.toggle()
                                }
                            }) {
                                Image(systemName: task.isDone ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(task.isDone ? .green : .gray)
                            }
                            
                            Text(task.title)
                                .strikethrough(task.isDone, color: .black)
                                .foregroundColor(task.isDone ? .gray : .black)
                        }
                    }
                    .onDelete(perform: deleteTask)
                }
            }
           
        }
    }
    
    private func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }
}

#Preview {
    ContentView()
}
