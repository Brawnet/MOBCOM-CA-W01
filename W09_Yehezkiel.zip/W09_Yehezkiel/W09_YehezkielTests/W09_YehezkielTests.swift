//
//  W09_YehezkielTests.swift
//  W09_YehezkielTests
//
//  Created by student on 06/11/25.
//

import Testing
@testable import W09_Yehezkiel

struct W09_YehezkielTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
