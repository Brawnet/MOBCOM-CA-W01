//
//  APIError.swift
//  W09_Yehezkiel
//
//  Created by student on 06/11/25.
//
import Foundation

enum APIError: LocalizedError {
    case badURL
    case network(underlying: Error)
    case server(status: Int)
    case decoding(underlying : Error)
    case unknown
    
    var errorDescription: String? {
        switch self {
            case .badURL:
            return "Bad URL"
        case .network(underlying: let error):
            return "Network error."
        case .server(status: let status):
            return "Server error."
        case .decoding(underlying: let error):
            return "Decoding error"
        case .unknown: return "unknown Error."
        }
    }
}
