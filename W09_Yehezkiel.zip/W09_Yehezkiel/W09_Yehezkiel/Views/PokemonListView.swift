import SwiftUI

struct PokemonListView: View {
    @StateObject private var vm = PokemonListViewModel()

    var body: some View {
        List {
            Section {
                if vm.filteredItems.isEmpty && vm.isLoading {
                    ProgressView("Loading Pokémon...")
                        .frame(maxWidth: .infinity, alignment: .center)
                }

                ForEach(vm.filteredItems) { item in
                    NavigationLink {
                        PokemonDetailView(nameORID: item.name,
                                          titleName: item.name.capitalized,
                                          artworkURL: item.artworkURL)
                    } label: {
                        HStack(spacing: 12) {
                            AsyncImage(url: item.artworkURL) { image in
                                image
                                    .resizable()
                                    .scaledToFit()
                            } placeholder: {
                                ProgressView()
                            }
                            .frame(width: 48, height: 48)

                            Text(item.name.capitalized)
                                .font(.body)
                        }
                    }
                    .task {
                        // infinite scroll trigger
                        await vm.loadMoreIfNeeded(currentItem: item)
                    }
                }
            }
            if vm.isLoading {
                        HStack {
                            Spacer()
                            ProgressView()
                            Spacer()
                        }
                    }
            if let err = vm.errorMessage {
                        VStack(spacing: 8) {
                            Text(err).foregroundColor(.red)
                            Button("Retry") { Task { await
                                vm.loadMoreIfNeeded(force: true) }}
                        }
                        .frame(maxWidth: .infinity)
            } else if !vm.isLoading && !vm.filteredItems.isEmpty {
                        // Optional footer when not loading
                        EmptyView()
            }
        }
        .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await vm.refresh() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .disabled(vm.isLoading)
                    .help("Refresh")
                }
            }
            .searchable(text: $vm.searchText, prompt: "Search Pokémon")
            .task { await vm.refresh() }
        }
}

