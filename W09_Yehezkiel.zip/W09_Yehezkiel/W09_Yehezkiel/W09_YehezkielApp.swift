//
//  W09_YehezkielApp.swift
//  W09_Yehezkiel
//
//  Created by student on 06/11/25.
//

import SwiftUI

@main
struct W09_YehezkielApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
