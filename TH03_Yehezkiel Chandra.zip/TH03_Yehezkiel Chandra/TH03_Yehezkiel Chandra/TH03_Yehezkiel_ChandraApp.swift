//
//  TH03_Yehezkiel_ChandraApp.swift
//  TH03_Yehezkiel Chandra
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct TH03_Yehezkiel_ChandraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
