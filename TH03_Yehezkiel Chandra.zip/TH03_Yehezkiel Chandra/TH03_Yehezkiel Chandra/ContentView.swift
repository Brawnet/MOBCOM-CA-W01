//
//  ContentView.swift
//  TH03_Yehezkiel Chandra
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView: View
{
    var body: some View
    {
        VStack
        {
            HStack
            {
                VStack
                {
                    Text("Good Morning,")
                    Text("Yehezkiel")
                        .padding(.leading, -40)

                }
                Spacer()
                
                Image("Manusia")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 75, height: 75)
                    .clipped()
                    .cornerRadius(15)
                
            }
            Spacer()
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
