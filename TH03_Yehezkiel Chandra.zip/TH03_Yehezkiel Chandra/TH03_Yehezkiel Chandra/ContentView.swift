//
//  ContentView.swift
//  TH03_Yehezkiel Chandra
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView: View
{
    @State private var searchText = ""
    var body: some View
    {
        TabView {
                    HomeView()
                        .tabItem {
                            Label("Beranda", systemImage: "house.fill")
                        }
                    
                    MapView()
                        .tabItem {
                            Label("Peta", systemImage: "map")
                        }
                    
                    StatsView()
                        .tabItem {
                            Label("Statistik", systemImage: "chart.bar.fill")
                        }
                    
                    ProfileView()
                        .tabItem {
                            Label("Profil", systemImage: "person.fill")
                        }
                }
    }
}

struct HomeView: View
{
    @State private var searchText = ""
    var body: some View
    {
        VStack
        {
            HStack
            {
                VStack
                {
                    Text("Good Morning,")
                        .font(.title)
                        .fontWeight(.bold)
                    Text("Yehezkiel")
                        .font(.title2)
                        .padding(.leading, -95)

                }
                Spacer()
                
                Image("Manusia")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 75, height: 75)
                    .clipped()
                    .cornerRadius(15)
                
            }
            .padding(.top, -30)
            
            TextField("Search...", text: $searchText)
                            .padding(10)
                            .background(Color(.systemGray6))
                            .cornerRadius(10)
                            .padding(.horizontal)
                            .padding(.top, 10)
                            .padding(.bottom, 10)
                            .frame(width: 400)
            
            Rectangle()
                .fill(Color(.systemGray6))
                .frame(width: 380, height: 250)
                .cornerRadius(20)
                .padding(.top, )
                .overlay
                {
                    VStack
                    {
                        Text("Hello Manusia Purba")
                                .foregroundColor(.black)
                                .font(.headline)
                                .padding(.top, -50)
                        
                        HStack
                        {
                            Rectangle()
                                .fill(.gray)
                                .frame(width: 160, height: 150)
                                .cornerRadius(20)
                                .padding(.leading, 20)
                                .padding(.bottom, -90 )
                                .overlay
                                {
                                    VStack
                                    {
                                        Image(systemName: "fork.knife")
                                            .font(.system(size: 50))
                                            .foregroundColor(.white)
                                            .padding(.top,100)
                                        Text("Makan")
                                            .foregroundColor(.white)
                                        Text("100KG sehari")
                                            .foregroundColor(.white)
                                    }
                                    .padding(.leading, 15)
                                }
                            Spacer()
                            Rectangle()
                                .fill(.gray)
                                .frame(width: 160, height: 150)
                                .cornerRadius(20)
                                .padding(.bottom, -90)
                                .overlay
                                {
                                    VStack
                                    {
                                        Image(systemName: "bed.double.fill")
                                            .font(.system(size: 50))
                                            .foregroundColor(.white)
                                            .padding(.top,75)
                                        Text("Tidur 15 jam sehari")
                                            .foregroundColor(.white)
                                    }
                                        
                                }
                            Spacer()
                        }
                    }

                }
            
            HStack
            {
                Rectangle()
                    .fill(.green)
                    .frame(width: 160, height: 100)
                    .cornerRadius(20)
                    .padding(.top, 10 )
                    .overlay
                    {
                        VStack
                        {
                            Image(systemName: "heart.fill")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding(.top, 15)
                            Text ("Avg Bpm 100")
                                .foregroundColor(.white)
                                .padding(5)
                                .padding(.top, -5)
                        }
                    }
                     
                Rectangle()
                    .fill(.green)
                    .frame(width: 160, height: 100)
                    .cornerRadius(20)
                    .padding(.top, 10)
                    .overlay
                    {
                        VStack
                        {
                            Image(systemName: "fork.knife")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding(.top, 15)
                            Text ("Avg Calori in 5KG")
                                .foregroundColor(.white)
                                .padding(5)
                                .padding(.top, -5)
                        }
                    }
                     
            }
            
            HStack
            {
                Rectangle()
                    .fill(.green)
                    .frame(width: 160, height: 100)
                    .cornerRadius(20)
                    .padding(.top, 10 )
                    .overlay
                    {
                        VStack
                        {
                            Image(systemName: "flame")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding(.top, 15)
                            Text ("Avg Calori Burn 10KG")
                                .foregroundColor(.white)
                                .padding(5)
                                .padding(.top, -5)
                        }
                    }
                     
                Rectangle()
                    .fill(.green)
                    .frame(width: 160, height: 100)
                    .cornerRadius(20)
                    .padding(.top, 10 )
                    .overlay
                    {
                        VStack
                        {
                            Image(systemName: "bed.double.fill")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding(.top, 15)
                            Text ("Sleep Hour 15")
                                .foregroundColor(.white)
                                .padding(5)
                                .padding(.top, -5)
                        }
                    }
                     
            }
            
            

        }
        .padding()
    }
}
struct MapView: View
{
    @State private var searchText = ""
    var body: some View
    {
        Text("Katakan Peta")
    }
}
struct StatsView: View
{
    @State private var searchText = ""
    var body: some View
    {
        Text("Statistik")
    }
}
struct ProfileView: View
{
    @State private var searchText = ""
    var body: some View
    {
        Text("Mosok")
    }
}
#Preview {
    ContentView()
}
