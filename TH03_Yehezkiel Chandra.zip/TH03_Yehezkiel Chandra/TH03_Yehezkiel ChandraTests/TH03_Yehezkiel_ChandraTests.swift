//
//  TH03_Yehezkiel_ChandraTests.swift
//  TH03_Yehezkiel ChandraTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import TH03_Yehezkiel_Chandra

struct TH03_Yehezkiel_ChandraTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
