//
//  _1Tests.swift
//  01Tests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import _1

struct _1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
