//
//  ContentView.swift
//  01
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        VStack(spacing:15) {
            Image("Yehezkiel")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.black, lineWidth: 4))
                .contentMargins(.zero)
                .padding(.top, -200)

            VStack(spacing: 15) {
                Text("Hi, I'm \(name)")
                    .font(.title)
                Text("My age is \(age)")
                Text("😀🤣🥲")
            }
            .padding()
            .background(Color.yellow)
            .cornerRadius(10)
        }
    }
    let name = "Yehezkiel"
    let age = 20
    
}

#Preview {
    ContentView()
}
