//
//  _1App.swift
//  01
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct _1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
