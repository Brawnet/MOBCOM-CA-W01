//
//  W04_ClassAssigntment_YehezkielTests.swift
//  W04-ClassAssigntment-YehezkielTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_ClassAssigntment_Yehezkiel

struct W04_ClassAssigntment_YehezkielTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
