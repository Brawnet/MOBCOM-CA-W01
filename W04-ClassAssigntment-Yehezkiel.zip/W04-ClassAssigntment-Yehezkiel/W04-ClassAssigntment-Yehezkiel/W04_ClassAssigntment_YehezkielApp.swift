//
//  W04_ClassAssigntment_YehezkielApp.swift
//  W04-ClassAssigntment-Yehezkiel
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_ClassAssigntment_YehezkielApp: App {
    var body: some Scene {
        WindowGroup {
            MovieListView()
        }
    }
}
