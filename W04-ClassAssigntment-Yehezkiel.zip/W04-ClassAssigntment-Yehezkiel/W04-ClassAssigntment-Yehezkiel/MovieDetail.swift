//
//  MovieDetail.swift
//  W04-ClassAssigntment-Yehezkiel
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View
{
    let movie: Movie

    var body: some View
    {
        ScrollView
        {
            VStack(alignment: .leading, spacing: 16)
            {
                AsyncImage(url: URL(string: movie.posterURL))
                { image in image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }
                placeholder:
                {
                    Rectangle()
                        .foregroundColor(.gray.opacity(0.3))
                        .aspectRatio(0.67, contentMode: .fit) // Rasio poster film
                        .overlay(ProgressView())
                }
                .cornerRadius(12)
                .shadow(radius: 10)

                VStack(alignment: .leading, spacing: 8) {
                    Text(movie.title)
                        .font(.largeTitle)
                        .fontWeight(.bold)

                    Text(movie.genre)
                        .font(.headline)
                        .foregroundColor(.secondary)
                }

                Divider()

                Text("Synopsis")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(movie.synopsis)
                    .font(.body)
            }
            .padding()
        }

    }
}

// Preview untuk MovieDetailView (opsional tapi membantu)
struct MovieDetailView_Previews: PreviewProvider {
    static var previews: some View {
        // Kita butuh NavigationView untuk melihat preview title bar
        NavigationView {
            MovieDetailView(movie: MovieData.movies[0])
        }
    }
}
