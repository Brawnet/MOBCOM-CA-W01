//
//  ContentView.swift
//  W04-ClassAssigntment-Yehezkiel
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieListView: View
{
    let allMovies = MovieData.movies
    @State private var searchFilm = ""
    
    var filteredMovies: [Movie] {
        if searchFilm.isEmpty {
            return allMovies
        } else {
            return allMovies.filter { $0.title.localizedCaseInsensitiveContains(searchFilm) }
        }
    }

    var body: some View
    {
        NavigationView
        {
            VStack
            {
                Text("UCFLIX")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundColor(.blue)
                
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    
                    TextField("Cari Judul Film", text: $searchFilm)
                }
                .padding(10)
                .background(Color(.systemGray6)) // Warna background abu-abu muda
                .cornerRadius(10)
                .padding(.horizontal)
            
                List(filteredMovies)
                {
                    movie in NavigationLink(destination: MovieDetailView(movie: movie))
                    {
                        HStack(spacing: 15)
                        {
                            AsyncImage(url: URL(string: movie.posterURL))
                            { image in
                                image
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                            }
                            placeholder:
                            {
                                Color.gray.opacity(0.3)
                            }
                            .frame(width: 80, height: 120)
                            .clipped()
                            .cornerRadius(8)

                            VStack(alignment: .leading, spacing: 5)
                            {
                                Text(movie.title)
                                    .font(.headline)
                                    .fontWeight(.bold)
                                Text(movie.genre)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 8)
                    }
                    
                }
            }
        }
    }
}

struct MovieListView_Previews: PreviewProvider {
    static var previews: some View {
        MovieListView()
    }
}
#Preview {
    MovieListView()
}
